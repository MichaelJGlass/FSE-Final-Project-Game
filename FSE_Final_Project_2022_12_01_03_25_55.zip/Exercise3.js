let ex3ScreenMode = 0;
let screenSetup = 0;
let timer = 10;
let score = 0;
let backColor = "black";
let lives = 3;
let screenSetup2 = 0;
//Sets up alphabet array to be randomly selected from.
const alph = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

let index = "1";
let indexN = 250;

function Exer3() {
  b1.hide();
  b2.hide();
  b3.hide();
  if (screenSetup == 0) {
    background("black");
    drawStars();
    index = random(alph);
    screenSetup++;
  }
  //Sets up the instruction screen 
  if (ex3ScreenMode == 0) {
    fill("white");
    textSize(45);
    text("Instructions", width / 3 + 20, height / 3);
    textSize(25);
    text(
      "The goal of this exercise is to develop typing skills and hand-eye",
      30,
      height / 2.5
    );
    text(
      "coordination. Letters will pop up on the screen and you will select",
      30,
      height / 2.5 + 40
    );
    text(
      "the key on the keyboard that corresponds to the key on the screen.",
      30,
      height / 2.5 + 80
    );
    text(
      "The faster you are able to select the key, the more points you will",
      30,
      height / 2.5 + 120
    );
    text(
      "earn. You have 3 lives before the game ends. Good luck!",
      30,
      height / 2.5 + 160
    );
    b1.html("Begin");
    b1.show();
    b1.position(width / 2.4, height / 1.4);
    b1.mousePressed(finishInstructions);
  } else if (ex3ScreenMode == 1) {
    background(backColor);
    drawLives();
    //Certain letters were uncentered, if statement below corrects their position to ensure they are centered.
    if (
      index == "C" ||
      index == "N" ||
      index == "O" ||
      index == "U" ||
      index == "H"
    ) {
      indexN = 225;
    } else if (index == "G" || index == "Q") {
      indexN = 210;
    } else if (index == "I") {
      indexN = 350;
    } else if (index == "J") {
      indexN = 280;
    } else if (index == "L") {
      indexN = 300;
    } else if (index == "M") {
      indexN = 200;
    } else if (index == "W") {
      indexN = 170;
    } else {
      indexN = 250;
    }
    //Sets up timer, decrements every time frameCount is a multiple of 120
    if (frameCount % 120 == 0 && timer > 0) {
      timer--;
    }
    if (timer == 0) {
      lives--;
      timer = 10;
    }
    //Sets up all text on screen
    textSize(500);
    text(index, indexN, height / 2 + 180);
    textSize(25);
    text("Time remaining: ", width / 2 - 110, 50);
    text(timer, width / 2 + 80, 51);
    text("Lives: ", 5, 75);
    text("Score: ", width / 2 - 40, height - 50);
    text(score, width / 2 + 40, height - 48);
  } else if (ex3ScreenMode == 2) {
    stroke(0.0001)
    if (screenSetup2 == 0) {
      background("black");
      drawStars();
      screenSetup2++;
    }
    textSize(80);
    text("Game Over!", width / 2 - 220, height / 2);
    textSize(25);
    text("Score Received: ", width / 2 - 120, height / 2 + 30);
    text(score, width / 2 + 80, height / 2 + 30);
    back.position(430, height / 2 + 50);
    back.html("Quit");
    b1.show();
    b1.position(230, height / 2 + 50);
    b1.html("Try Again");
    b1.mousePressed(resetGame);
  }
}
//Switches screen from instructions to actual game
function finishInstructions() {
  ex3ScreenMode++;
  background("black");
  b1.hide();
  textSize(50);
}

//If user types correct key, adds to score, plays sound and makes background green. If user types wrong key, takes a life, plays a negative noise, and makes background red.
function keyTyped() {
  if (key.toUpperCase() === index && ex3ScreenMode == 1) {
    score += timer;
    timer = 10;
    success.play()
    index = random(alph);
    backColor = "green";
  } else if (key.toUpperCase() !== index && ex3ScreenMode == 1) {
    backColor = "red";
    fail.play()
    lives--;
  }
}

//Draws the lives on the screen.
function drawLives() {
  fill("white");
  if (lives == 1 || lives == 2 || lives == 3) {
    rocket.resize(25, 50)
    image(rocket, 25, 100)
  }
  if (lives == 2 || lives == 3) {
    image(rocket, 25, 160)
  }
  if (lives == 3) {
    image(rocket, 25, 220)
  }
  if (lives == 0) {
    ex3ScreenMode = 2;
  }
  fill("white");
}

//Resets game from game over screen and ensures all values are default.
function resetGame() {
  screenSetup = 0;
  screenSetup2 = 0;
  ex3ScreenMode = 1;
  score = 0;
  backColor = "black";
  lives = 3;
  back.position(0, 0);
  back.html("< Back");
}
