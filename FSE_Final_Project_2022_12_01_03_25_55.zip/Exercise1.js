//Sets up default values to ensure exercise 1 is the same every time it is launched.
let setScreen = 0;
let setScreenLose = 0;
let ex1ScreenMode = 0;
let d = 70;
let p1 = d;
let p2 = p1 + d;
let p3 = p2 + d;
let p4 = p3 + d;
let circleY = 350;
let ellipseY = 350;
let YVel = 2;
let direction = 0;
let projectileX = 400;
let projectileY = 100;
let projectileStatus = 0;
let invaderX = 0;
let live = 3;
let scores = 0;

//Called in the draw function, repeated constantly
function Exer1() {
  b1.hide();
  b2.hide();
  b3.hide();
  
  //Instruction screen is run one time and not being constantly drawn, code below is to make sure that the background is drawn once. If not, drawStars() would repetitely be called and stars would bounce all over the screen
  if (ex1ScreenMode == 0) {
    if (setScreen == 0) {
      background("black");
      drawStars();
      invaderX = width / 2 - 25;
      setScreen++;
    }
    //Instructions
    fill("white");
    textSize(45);
    text("Instructions", width / 3 + 20, height / 3);
    textSize(25);
    text(
      "The goal of this exercise is to develop timing skills and hand-eye",
      30,
      height / 2.5
    );
    text(
      "coordination. A UFO will bounce back and forth at the top of the",
      30,
      height / 2.5 + 40
    );
    text(
      "screen, and when the user presses the SPACE key, a projectile will",
      30,
      height / 2.5 + 80
    );
    text(
      "shoot. The goal is to hit the enemy at the bottom of the screen as",
      30,
      height / 2.5 + 120
    );
    text(
      "many times as you can. If you miss 3 times, you lose. Good Luck!",
      30,
      height / 2.5 + 160
    );
    b1.html("Begin");
    b1.show();
    b1.position(width / 2.4, height / 1.4);
    b1.mousePressed(updateScreenModeEX1);
  } else if (ex1ScreenMode == 1) {
    if (live == 0) {
      updateScreenModeEX1();
    }
    //Sets up UFO and how it moves across screen
    stroke(255);
    background(48, 20, 45);
    drawLive();
    stroke(153);
    line(700, 100, 100, 100);
    line(100, 70, 100, 130);
    line(700, 70, 700, 130);

    fill(0);
    circle(circleY, 50, 50);

    fill(0);
    ellipse(ellipseY, 60, 90, 20);

    circleY = circleY + YVel;
    ellipseY = ellipseY + YVel;

    if (circleY > 670) {
      YVel = YVel * -1;
    }
    if (ellipseY < 130) {
      YVel = YVel * -1;
    }
    //Sets up non-moving items on screen
    fill("white");
    textSize(25);
    text("Lives: ", 5, 75);
    text("Score: ", width / 2 - 40, height - 50);
    text(scores, width / 2 + 40, height - 48);
    line(100, 500, 700, 500);
    line(100, 470, 100, 530);
    line(700, 470, 700, 530);
    if (projectileStatus == 1) {
      projectileX = circleY;
      drawProjectile();
    }
    drawInvader();
  } else if (ex1ScreenMode == 2) {
    stroke(0.0001)
    if(setScreenLose == 0) {
       background("black")
       drawStars()
       setScreenLose++
       }
    textSize(80);
    fill("white");
    text("Game Over!", width / 2 - 220, height / 2);
    textSize(25);
    text("Score Received: ", width / 2 - 120, height / 2 + 30);
    text(scores, width / 2 + 80, height / 2 + 30);
    back.position(430, height / 2 + 50);
    back.html("Quit");
    b1.show();
    b1.position(230, height / 2 + 50);
    b1.html("Try Again");
    b1.mousePressed(resetGame1);
  }
}
    //Draws the square that the user targets with UFO
function drawInvader() {
  fill("black");
  square(invaderX, 475, 50);
}

//Shoots a projectile at target each time space button is pressed.
function keyPressed() {
  if (key == " ") {
    projectileStatus = 1;
    if (YVel > 0) {
      direction = 2;
    } else {
      direction = -2;
    }
    YVel = 0;
  }
}

//Draws lives that decrease each time user makes a mistake
function drawLive() {
  fill("white");
  if (live == 1 || live == 2 || live == 3) {
    rocket.resize(25, 50)
    image(rocket, 25, 100)
  }
  if (live == 2 || live == 3) {
    image(rocket, 25, 160)
  }
  if (live == 3) {
    image(rocket, 25, 220)
  }
  fill("white");
}

//Draws circle that fires from UFO's position and hits target
function drawProjectile() {
  if (setScreen == 1) {
    fill("red");
    circle(projectileX, projectileY, 25);
    if (projectileY != 500) {
      projectileY += 5;
    } else {
      projectileY = 100;
      YVel = direction;
      projectileStatus = 0;
    }

    if (
      projectileX <= invaderX + 50 &&
      projectileX >= invaderX &&
      projectileY == 500
    ) {
      invaderX = random(150, 650);
      scores += 10;
      success.play()
    } else if (
      (projectileX >= invaderX + 50 || projectileX <= invaderX) &&
      projectileY == 500
    ) {
      live--;
      fail.play()
    }
  }
}

//Updates screen from instruction, to game, to game over screen.
function updateScreenModeEX1() {
  ex1ScreenMode++;
}

//Resets game from game over screen and makes sure all values are default.
function resetGame1() {
  ex1ScreenMode = 1;
  d = 70;
  p1 = d;
  p2 = p1 + d;
  p3 = p2 + d;
  p4 = p3 + d;
  circleY = 350;
  ellipseY = 350;
  setScreenLose = 0;
  YVel = 1;
  direction = 0;
  projectileX = 400;
  projectileY = 100;
  projectileStatus = 0;
  live = 3;
  scores = 0;
  back.position(0, 0);
  back.html("< Back");
}
