let sScreen = 0;
let ssScreen = 0;
let ex2ScreenMode = 0;
let ex2screenSetup2 = 0;
let ellipseUFOX = 400;
let ellipseUFOY = 410;

let speedUFOX = 2;
let speedUFOY = 2;

let directionUFO = [-1, 0, 1];
let xdirection = 1;
let ydirection = 0;

let ex2Score = 0;
let timer2 = 3;

//Called in the draw function to be repeated
function Exer2() {
  b1.hide();
  b2.hide();
  b3.hide();
  
  //Sets up instruction screen, same idea as instruction screen in Exercise1.js
  if (ex2ScreenMode  == 0) {
    if (ssScreen == 0) {
      background("black");
      drawStars();
      ssScreen++;
    }
    fill("white");
    textSize(45);
    text("Instructions", width / 3 + 20, height / 3);
    textSize(25);
    text(
      "The goal of this exercise is to develop mouse skills and hand-eye",
      30,
      height / 2.5
    );
    text(
      "coordination. A UFO will bounce back and forth all around the",
      30,
      height / 2.5 + 40
    );
    text(
      "screen, and the user must follow the UFO with their mouse. The more",
      30,
      height / 2.5 + 80
    );
    text(
      "you follow the UFO, the more points you will score. If your mouse",
      30,
      height / 2.5 + 120
    );
    text(
      "leaves the UFO for more than 3 seconds, the game ends. Good Luck!",
      30,
      height / 2.5 + 160
    );
    b1.html("Begin");
    b1.show();
    b1.position(width / 2.4, height / 1.4);
    b1.mousePressed(updateScreenModeEX2);
  } 
  
//Sets up the game
  else if (ex2ScreenMode == 1) {
    if (sScreen == 0) {
      ellipseUFOX = 400;
      ellipseUFOY = 410;
      sScreen++;
    }
    
    background("black");
    fill("white")
    noStroke()
    text("Score: ", width/2 - 70, 50)
    text(int(ex2Score) * 10, width/2 + 20, 50)
    text("Game Over Timer: ", 0, height - 10)
    text(timer2, 220, height - 10)
    fill(119, 247, 215);
    stroke("red");
    //UFO calls array to get a random direction, bounces off walls at a set speed
    ellipse(ellipseUFOX, ellipseUFOY, 100, 60);

    fill(59, 59, 59);
    ellipse(ellipseUFOX, ellipseUFOY + 10, 180, 40);

    ellipseUFOX += speedUFOX * xdirection;
    ellipseUFOY += speedUFOY * ydirection;

    if (ellipseUFOX >= width - 90 || ellipseUFOX <= 90) {
      speedUFOX *= -1;
      ydirection = random(directionUFO);
    }
    if (ellipseUFOY >= height - 30 || ellipseUFOY <= 80) {
      speedUFOY *= -1;
      xdirection = random(directionUFO);
    }
    
    //Keeps timer from deincrementing, as long as user keeps mouse within the square that the UFO occupies
      if(mouseX > ellipseUFOX - 90 && mouseX < ellipseUFOX + 90 && mouseY > ellipseUFOY - 30 && mouseY < ellipseUFOY + 30) {
    ex2Score += 0.021
    timer2 = 3
  }
  else{
    if (frameCount % 60 == 0 && timer > 0) {
      timer2--;
      fail.play()
    }
    if (timer2 == 0) {
      updateScreenModeEX2()
    }
  }
    
  }
//Game over screen  
   else if (ex2ScreenMode == 2) {
    stroke(0.0001)
     if (ex2screenSetup2 == 0) {
      background("black");
      fill("white")
      noStroke("white")
      drawStars();
      ex2screenSetup2++;
    }
    textSize(80);
    fill("white")
    text("Game Over!", width / 2 - 220, height / 2);
    textSize(25);
    text("Score Received: ", width / 2 - 120, height / 2 + 30);
    text(int(ex2Score), width / 2 + 80, height / 2 + 30);
    back.position(430, height / 2 + 50);
    back.html("Quit");
    b1.show();
    b1.position(230, height / 2 + 50);
    b1.html("Try Again");
    b1.mousePressed(resetGames);
  }

}

//Increments from instruction screen, to actual game, to game over screen 
function updateScreenModeEX2() {
  ex2ScreenMode++;
}

//Resets screen to default values from game over screen
function resetGames() {
  sScreen = 0;
  ssScreen = 0;
  ex2ScreenMode = 1;
  ex2screenSetup2 = 0;
  ellipseUFOX = 400;
  ellipseUFOY = 410;
   xdirection = 1;
   ydirection = 0;

   ex2Score = 0;
   timer2 = 3;
    back.position(0, 0);
  back.html("< Back");
}
