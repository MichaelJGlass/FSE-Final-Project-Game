//Screen control
let screenMode = 0;

//buttons
let b1;
let b2;
let b3;
let back;

//Loads all files that will be used in the code
function preload() {
  rocket = loadImage('rocket.png');
  soundFormats('mp3');
  fail = loadSound('fail.mp3');
  success = loadSound('success.mp3')
}

//Creates buttons and creates background that is not constantly being drawn
function setup() {
  createCanvas(800, 700);
  background('black');
  b1 = createButton("Start")
  b2 = createButton("Quit")
  b3 = createButton("Exercise 3")
  back = createButton("< Back")
  drawStars()
}

function draw() {
//Statement that calls other methods to be constantly drawn as other screens
  if(screenMode == 0) {
    screen1()
  }
  else if(screenMode == 1) {
    screen2()
  }
  else if(screenMode == 2) {
    Exer1();
  }
  else if(screenMode == 3) {
    Exer2();
  }
  else if(screenMode == 4) {
    Exer3();
  }
}

//Sets up menu with a start and a quit button to initiate UI
function screen1() {
  fill('white');
  textSize(45);
  text('Space Game', width/3, height/3)
  
  b1.html("Start")
  b1.position(width/2.4, height/2.15)
  b1.size(150, 50)
  b1.style("font-size", "25px")
  b1.mousePressed(updateScreen)
  
  b2.html("Quit")
  b2.position(width/2.4, height/1.7)
  b2.size(150, 50)
  b2.style("font-size", "25px")
  b2.mousePressed(quitBut)
}

//Creates exercise selection screen that allows user to navigate to each screen
function screen2() {
  fill('white');
  textSize(45);
  text('Select Exercise', width/3.2, height/3)
  
  b1.html("Exercise 1")
  b1.mousePressed(updateToExercise1)
  
  b2.html("Exercise 2")
  b2.mousePressed(updateToExercise2)
  
  b3.position(width/2.4, height/1.4)
  b3.size(150, 50)
  b3.style("font-size", "25px")
  b3.mousePressed(updateToExercise3)
  
  back.position(0, 0)
  back.size(150, 50)
  back.style("font-size", "25px")
  back.html("< Back")
  back.mouseClicked(backBut)
}

//Sets screen to exercise selection screen
function updateScreen() {
  screenMode = 1;
  background('black')
  drawStars()
  back.show()
  b3.show()
}

//Long back button that essentially resets every value every time the back button is selected
function backBut() {
  stroke(0.0001)
  screenMode = 0;
  background('black')
  drawStars()
  back.hide()
  b3.hide()
  b1.show()
  b2.show()
  screenSetup = 0
  screenSetup2 = 0
  ex2ScreenMode = 0
  ex3ScreenMode = 0
  setScreen = 0
  sScreen = 0
  ssScreen = 0
  ex2Score = 0
  timer2 = 3
  ex2screenSetup2 = 0
  score = 0;
  backColor = "black"
  lives = 3
  ex2screenSetup2 = 0
  setScreenLose = 0;
  ex1ScreenMode = 0
}

function quitBut() {
  remove()
}


function drawStars() {
  let i = 0
  while(i < height) {
    i++
    fill('white')
    circle(random(width), i, 2.5)
  }
}

//Ensures default values are correct and transfers screen to Exercise1.js
function updateToExercise1() {
  screenMode = 2
  setScreen = 0
  live = 3

}

//Ensures default values are correct and transfers screen to Exercise2.js
function updateToExercise2() {
  screenMode = 3
  setupScreen = 0
}

//Ensures default values are correct and transfers screen to Exercise3.js
function updateToExercise3() {
  screenMode = 4
  instruct = 0
  screenSetup = 0
  ex3ScreenMode = 0
}

